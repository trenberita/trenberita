---
name: Feature request
about: Suggest a feature that we can implement.

---

### Description:
<!-- Describe the requested feature in a clear and concise way. -->

### Alternatives:
<!-- If we don't implement this feature, what would be the best alternatives to achieve the same functionality? -->